﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_Borisov
{
    public class Computer
    {
        //поля
        private string processorName;
        private double frequency;
        private int ramSize;

        // Доп. поля

        //Производитель
        private string manufacturer;
        //Дата производства
        private DateTime dateProduction;

        //Конструктор
        public Computer(string ProcessorName, double Frequency, int RamSize, string Manufacturer, DateTime Dateproduction)
        {
            processorName = ProcessorName;
            frequency = Frequency;
            ramSize = RamSize;
            manufacturer = Manufacturer;
            dateProduction = Dateproduction;
        }
        // Методы доступа к полям (свойства)
        public string ProcessorName()
        {
            return processorName;
        }

        public double Frequency()
        {
            return frequency;
        }
        public int RamSize()
        {
            return ramSize;
        }
        public string Manufacturer()
        {
            return manufacturer;
        }
        public DateTime DateProduction()
        {
            return dateProduction;
        }
        //Расчет качества
        public virtual double CalculateQuality()
        {
            return 0.3 * frequency + ramSize;
        }

        public virtual string GetInfo()
        {
            return $"Компьютер: {manufacturer} Процессор: {processorName} {frequency} МГц, ОЗУ: {ramSize} МБ," +
                   $" Дата производства: {dateProduction} Качество (Q): {CalculateQuality():F2}";
        }
        //Добавление компьютера в коллекцию
        public static void AddComputer(List<Computer> computers, Computer computer)
        {
            computers.Add(computer);
            Console.WriteLine($"Компьютер {computer.processorName} добавлен");
        }
        //Добавление компьютера в коллекцию с параметрами. Перегрузка
        public static void AddComputer(List<Computer> computers, string processorName, double frequency,
                                     int ramSize, string manufacturer, DateTime dateProduction)
        {
            Computer computer = new Computer(processorName, frequency, ramSize, manufacturer, dateProduction);
            computers.Add(computer);
            Console.WriteLine($"Компьютер {processorName} создан и добавлен");
        }
        // Удаление компьютера
        public static bool RemoveComputer(List<Computer> computers, Computer computer)
        {
            bool removed = computers.Remove(computer);
            if (removed)
            {
                Console.WriteLine($"Компьютер {computer.processorName} удален из коллекции");
            }
            else
            {
                Console.WriteLine($"Компьютер {computer.processorName} не найден");
            }
            return removed;
        }

        // Удаление компьютера по индексу. Перегрузка
        public static bool RemoveComputer(List<Computer> computers, int index)
        {
            if (index < 0 || index >= computers.Count)
            {
                Console.WriteLine($"Индекс выходит за пределы коллекции");
            }
            Computer computer = computers[index];
            computers.RemoveAt(index);
            Console.WriteLine($"Компьютер {computer.processorName} удален по индексу");
            return true;
        }
    }
}