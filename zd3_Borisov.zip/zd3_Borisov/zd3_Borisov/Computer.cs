﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_Borisov
{
    public class Computer
    {
        public string processorName { get; set; }
        public double frequancy { get; set; }
        public int ramSize { get; set; }
        //Доп. поля
        //Производитель
        public string manufacturer { get; set; }
        //дата производства
        public DateTime dateProduction { get; set; }
        //Конструктор
        public Computer(string ProcessorName, double Frequancy, int RamSize, string Manufacturer, DateTime Dateproduction)
        {
            processorName = ProcessorName;
            frequancy = Frequancy;
            ramSize = RamSize;
            manufacturer = Manufacturer;
            dateProduction = Dateproduction;
        }
        //Расчет качества
        public virtual double CalculateQuality()
        {
            return 0.3 * frequancy + ramSize;
        }
        //Вывод информации
        public virtual string GetInfo()
        {
            return $"Компьютер: {manufacturer} Процессор: {processorName} {frequancy} МГц,+" +
                $" ОЗУ: {ramSize} мб, Дата производства: {dateProduction} +" +
                $"Качество (Q): {CalculateQuality():F2}";
        }
    }
}
