﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_Borisov
{
    public class ImprovementComputer : Computer
    {
        // Поле
        private int hardDriveSize;

        // Доп. свойства (только в классе-наследнике)
        private bool HasSsd { get; set; }
        private int Memory { get; set; }

        // Конструктор
        public ImprovementComputer(string processorName, double frequency, int ramSize, string manufacturer,
            DateTime dateproduction, int HardDriveSize, bool hasSsd, int memory)
            : base(processorName, frequency, ramSize, manufacturer, dateproduction)
        {
            hardDriveSize = HardDriveSize;
            HasSsd = hasSsd;
            Memory = memory;
        }
        // Метод доступа к полям
        public int HardDriveSize()
        {
            return hardDriveSize;
        }

        //переопределенный метод расчета качества
        public override double CalculateQuality()
        {
            double baseQuality = base.CalculateQuality();
            return baseQuality + 0.5 * hardDriveSize;
        }

        //переопределенный метод вывода информации
        public override string GetInfo()
        {
            return base.GetInfo() + $"HDD: {hardDriveSize} Гб, SSD: {(HasSsd ? "да" : "нет")}, память: {Memory} Мб,+" +
                   $" Общее качество: {CalculateQuality():F2}";
        }      
    }
}