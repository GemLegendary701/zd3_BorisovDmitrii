﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3_Borisov
{
    public class ImprovementComputer : Computer
    {
        //P
        public int HardDriveSize { get; set; }
        //доп. Свойства
        public bool HasSsd { get; set; }
        public int Memory { get; set; }
        //Конструктор
        public ImprovementComputer(string processorName, double frequancy, int ramSize, string manufacturer,
            DateTime dateproduction, int hardDriveSize, bool hasSSd, int memory) 
            : base(processorName, frequancy, ramSize, manufacturer, dateproduction)
        {
            HardDriveSize = hardDriveSize;
            HasSsd = hasSSd;
            Memory = memory;
        }
        //переопределенный метод расчета качества
        public override double CalculateQuality()
        {
            double baseQuality = base.CalculateQuality();
            return baseQuality + 0.5 * HardDriveSize;
        }
        //переопределенный метод вывода информации
        public override string GetInfo()
        {
            return base.GetInfo() + $"HDD: {HardDriveSize} Гб, SSD: {(HasSsd ? "да" : "нет")}," +
                $" память: {Memory} Мб,+" +
                $" Общее качество: {CalculateQuality():F2}";
        }
    }
}
