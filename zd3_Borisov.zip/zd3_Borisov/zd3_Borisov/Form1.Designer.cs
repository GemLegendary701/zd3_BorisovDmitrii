﻿namespace zd3_Borisov
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            buttonAdd = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBoxMemory = new TextBox();
            textBoxHdd = new TextBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            dateTimePicker1 = new DateTimePicker();
            textBoxManufacturer = new TextBox();
            textBoxRam = new TextBox();
            textBoxFrequency = new TextBox();
            textBoxProcessor = new TextBox();
            groupBox2 = new GroupBox();
            buttonReset = new Button();
            buttonFilter = new Button();
            label9 = new Label();
            textBoxFilter = new TextBox();
            listBox1 = new ListBox();
            labelStats = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(buttonAdd);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(textBoxMemory);
            groupBox1.Controls.Add(textBoxHdd);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(textBoxManufacturer);
            groupBox1.Controls.Add(textBoxRam);
            groupBox1.Controls.Add(textBoxFrequency);
            groupBox1.Controls.Add(textBoxProcessor);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(422, 428);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Добавить компьютер";
            // 
            // buttonAdd
            // 
            buttonAdd.Location = new Point(144, 325);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(100, 46);
            buttonAdd.TabIndex = 20;
            buttonAdd.Text = "Добавить";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(287, 250);
            label7.Name = "label7";
            label7.Size = new Size(48, 15);
            label7.TabIndex = 14;
            label7.Text = "Память";
            label7.Visible = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 250);
            label6.Name = "label6";
            label6.Size = new Size(32, 15);
            label6.TabIndex = 13;
            label6.Text = "HDD";
            label6.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(235, 109);
            label5.Name = "label5";
            label5.Size = new Size(32, 15);
            label5.TabIndex = 12;
            label5.Text = "Дата";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 109);
            label4.Name = "label4";
            label4.Size = new Size(92, 15);
            label4.TabIndex = 11;
            label4.Text = "Производитель";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(287, 34);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 10;
            label3.Text = "ОЗУ (Мб)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(144, 34);
            label2.Name = "label2";
            label2.Size = new Size(85, 15);
            label2.TabIndex = 9;
            label2.Text = "Частота (МГц)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 34);
            label1.Name = "label1";
            label1.Size = new Size(69, 15);
            label1.TabIndex = 8;
            label1.Text = "Процессор";
            // 
            // textBoxMemory
            // 
            textBoxMemory.Location = new Point(287, 268);
            textBoxMemory.Name = "textBoxMemory";
            textBoxMemory.Size = new Size(100, 23);
            textBoxMemory.TabIndex = 7;
            textBoxMemory.Visible = false;
            // 
            // textBoxHdd
            // 
            textBoxHdd.Location = new Point(6, 268);
            textBoxHdd.Name = "textBoxHdd";
            textBoxHdd.Size = new Size(100, 23);
            textBoxHdd.TabIndex = 6;
            textBoxHdd.Visible = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(157, 268);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(72, 19);
            checkBox2.TabIndex = 5;
            checkBox2.Text = "Есть SSD";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.Visible = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(121, 207);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(159, 19);
            checkBox1.TabIndex = 4;
            checkBox1.Text = "Улучшеный компьютер";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(235, 127);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(152, 23);
            dateTimePicker1.TabIndex = 3;
            // 
            // textBoxManufacturer
            // 
            textBoxManufacturer.Location = new Point(6, 127);
            textBoxManufacturer.Name = "textBoxManufacturer";
            textBoxManufacturer.Size = new Size(100, 23);
            textBoxManufacturer.TabIndex = 2;
            // 
            // textBoxRam
            // 
            textBoxRam.Location = new Point(287, 52);
            textBoxRam.Name = "textBoxRam";
            textBoxRam.Size = new Size(100, 23);
            textBoxRam.TabIndex = 1;
            // 
            // textBoxFrequency
            // 
            textBoxFrequency.Location = new Point(144, 52);
            textBoxFrequency.Name = "textBoxFrequency";
            textBoxFrequency.Size = new Size(100, 23);
            textBoxFrequency.TabIndex = 1;
            // 
            // textBoxProcessor
            // 
            textBoxProcessor.Location = new Point(6, 52);
            textBoxProcessor.Name = "textBoxProcessor";
            textBoxProcessor.Size = new Size(100, 23);
            textBoxProcessor.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(buttonReset);
            groupBox2.Controls.Add(buttonFilter);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(textBoxFilter);
            groupBox2.Controls.Add(listBox1);
            groupBox2.Location = new Point(466, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1209, 428);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Список компьютеров";
            // 
            // buttonReset
            // 
            buttonReset.Location = new Point(126, 81);
            buttonReset.Name = "buttonReset";
            buttonReset.Size = new Size(107, 46);
            buttonReset.TabIndex = 19;
            buttonReset.Text = "Сброс";
            buttonReset.UseVisualStyleBackColor = true;
            buttonReset.Click += buttonReset_Click;
            // 
            // buttonFilter
            // 
            buttonFilter.Location = new Point(6, 81);
            buttonFilter.Name = "buttonFilter";
            buttonFilter.Size = new Size(107, 46);
            buttonFilter.TabIndex = 18;
            buttonFilter.Text = "Фильтр";
            buttonFilter.UseVisualStyleBackColor = true;
            buttonFilter.Click += buttonFilter_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(6, 34);
            label9.Name = "label9";
            label9.Size = new Size(153, 15);
            label9.TabIndex = 17;
            label9.Text = "Введите текст для фильтра";
            // 
            // textBoxFilter
            // 
            textBoxFilter.Location = new Point(6, 52);
            textBoxFilter.Name = "textBoxFilter";
            textBoxFilter.Size = new Size(227, 23);
            textBoxFilter.TabIndex = 16;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(6, 153);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(1197, 274);
            listBox1.TabIndex = 0;
            // 
            // labelStats
            // 
            labelStats.AutoSize = true;
            labelStats.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            labelStats.Location = new Point(466, 454);
            labelStats.Name = "labelStats";
            labelStats.Size = new Size(113, 30);
            labelStats.TabIndex = 2;
            labelStats.Text = "labelStatus";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1687, 821);
            Controls.Add(labelStats);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Система управления компьютеров";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBoxManufacturer;
        private TextBox textBoxRam;
        private TextBox textBoxFrequency;
        private TextBox textBoxHdd;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private DateTimePicker dateTimePicker1;
        private TextBox textBoxProcessor;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBoxMemory;
        private Label label7;
        private GroupBox groupBox2;
        private ListBox listBox1;
        private Label label9;
        private TextBox textBoxFilter;
        private Button buttonReset;
        private Button buttonFilter;
        private Label labelStats;
        private Button buttonAdd;
    }
}
