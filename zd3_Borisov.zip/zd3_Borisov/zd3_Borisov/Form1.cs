﻿namespace zd3_Borisov
{
    public partial class Form1 : Form
    {
        // список для хранения компьютеров
        private List<Computer> computersList = new List<Computer>();
        public Form1()
        {
            InitializeComponent();
            InitializeControlsState();
            labelStats.Text = "Добро пожаловать в систему управления компьютеров";
        }
        //Инициализация начального состояния элементов
        private void InitializeControlsState()
        {
            textBoxHdd.Visible = label6.Visible = false;
            textBoxMemory.Visible = label7.Visible = false;
            checkBox2.Visible = false;
            buttonReset.Visible = false;
        }
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxProcessor.Text) ||
               string.IsNullOrWhiteSpace(textBoxFrequency.Text) ||
               string.IsNullOrWhiteSpace(textBoxRam.Text) ||
               string.IsNullOrWhiteSpace(textBoxManufacturer.Text))
            {
                MessageBox.Show("Заполните все поля");
            }
            try
            {
                Computer newComputer;
                if (checkBox1.Checked)
                {
                    newComputer = new ImprovementComputer(
                        textBoxProcessor.Text,
                        double.Parse(textBoxFrequency.Text),
                        int.Parse(textBoxRam.Text),
                        textBoxManufacturer.Text,
                        dateTimePicker1.Value,
                        int.Parse(textBoxHdd.Text),
                        checkBox2.Checked,
                        int.Parse(textBoxMemory.Text));
                }
                else
                {
                    newComputer = new Computer(
                        textBoxProcessor.Text, double.Parse(textBoxFrequency.Text),
                        int.Parse(textBoxRam.Text), textBoxManufacturer.Text, dateTimePicker1.Value);
                }
                computersList.Add(newComputer);
                ClearInputs();
                UpdateComputerList();
                UpdateStatistics();
                MessageBox.Show("Компьютер добавлен!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Проверьте правильность ввода значений");
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBoxHdd.Visible = label6.Visible = checkBox1.Checked;
            textBoxMemory.Visible = label7.Visible = checkBox1.Checked;
            checkBox2.Visible = checkBox1.Checked;
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            if (computersList.Count == 0)
            {
                MessageBox.Show("Нет компьютеров для фильтрации");
                return;
            }
            string filterText = textBoxFilter.Text.ToLower().Trim();
            var filteredComputers = computersList
                .Where(c => c.manufacturer.ToLower().Contains(filterText) ||
                           c.processorName.ToLower().Contains(filterText))
                .OrderByDescending(c => c.CalculateQuality());
            listBox1.Items.Clear();
            foreach (var computer in filteredComputers)
            {
                listBox1.Items.Add(computer.GetInfo());
            }
            buttonReset.Visible = true;
            UpdateStatistics();
        }
        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxFilter.Text = "";
            UpdateComputerList();
            UpdateStatistics();
            buttonReset.Visible = false;
        }
        //Обновление списка компьютеров
        private void UpdateComputerList()
        {
            listBox1.Items.Clear();
            var sorted = computersList.OrderByDescending(c => c.CalculateQuality());

            foreach (var comp in sorted)
            {
                listBox1.Items.Add(comp.GetInfo());
            }
        }       
        //Очистка всех полей ввода
        private void ClearInputs()
        {
            textBoxProcessor.Clear();
            textBoxFrequency.Clear();
            textBoxRam.Clear();
            textBoxManufacturer.Clear();
            textBoxHdd.Clear();
            textBoxMemory.Clear();
            checkBox2.Checked = false;
            checkBox1.Checked = false;
        }
        //Метод для отображения статистики
        private void UpdateStatistics()
        {
            // Проверяем, есть ли компьютеры в списке
            if (computersList.Count == 0)
            {
                labelStats.Text = "Нет данных о компьютерах";
                return;
            }
            int totalComputers = computersList.Count;
            int improvedCount = computersList.OfType<ImprovementComputer>().Count();
            int regularCount = totalComputers - improvedCount;
            labelStats.Text =
                $"Общее количество: {totalComputers}\n" +
                $"─────────────────────\n" +
                $"• Обычных: {regularCount}\n" +
                $"• Улучшенных: {improvedCount}";
        }
    }
}