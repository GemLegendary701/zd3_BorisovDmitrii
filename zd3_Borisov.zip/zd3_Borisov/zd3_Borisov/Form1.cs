﻿namespace zd3_Borisov
{
    public partial class Form1 : Form
    {
        //список хранения компьютеров
        private List<Computer> computersList = new List<Computer>();

        public Form1()
        {
            InitializeComponent();
            InitializeControls();
            labelStats.Text = "Добро пожаловать в систему управления компьютеров";
        }

        //Начальное состояние элементов
        private void InitializeControls()
        {
            textBoxHdd.Visible = label6.Visible = false;
            textBoxMemory.Visible = label7.Visible = false;
            checkBox2.Visible = false;
            buttonReset.Visible = false;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxProcessor.Text) ||
               string.IsNullOrWhiteSpace(textBoxFrequency.Text) ||
               string.IsNullOrWhiteSpace(textBoxRam.Text) ||
               string.IsNullOrWhiteSpace(textBoxManufacturer.Text))
            {
                MessageBox.Show("Заполните все поля");
            }
            try
            {
                Computer newComputer;
                if (checkBox1.Checked)
                {
                    if (string.IsNullOrWhiteSpace(textBoxHdd.Text) ||
                        string.IsNullOrWhiteSpace(textBoxMemory.Text))
                    {
                        MessageBox.Show("Заполните все дополнительные поля для улучшенного компьютера");
                    }

                    newComputer = new ImprovementComputer(
                        textBoxProcessor.Text,
                        double.Parse(textBoxFrequency.Text),
                        int.Parse(textBoxRam.Text),
                        textBoxManufacturer.Text,
                        dateTimePicker1.Value,
                        int.Parse(textBoxHdd.Text),
                        checkBox2.Checked,
                        int.Parse(textBoxMemory.Text));
                }
                else
                {
                    newComputer = new Computer(
                        textBoxProcessor.Text, double.Parse(textBoxFrequency.Text), int.Parse(textBoxRam.Text), textBoxManufacturer.Text,
                        dateTimePicker1.Value);
                }
                computersList.Add(newComputer);
                ClearInputs();
                UpdateComputerList();
                UpdateLabelStatus();
                MessageBox.Show("Компьютер добавлен!");
            }
            catch (Exception)
            {
                MessageBox.Show("Проверьте правильность ввода числовых значений");
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBoxHdd.Visible = label6.Visible = checkBox1.Checked;
            textBoxMemory.Visible = label7.Visible = checkBox1.Checked;
            checkBox2.Visible = checkBox1.Checked;
        }
        private void buttonFilter_Click(object sender, EventArgs e)
        {
            if (computersList.Count == 0)
            {
                MessageBox.Show("Нет компьютеров для фильтра");
                return;
            }

            string filterText = textBoxFilter.Text.ToLower().Trim();
            var filteredComputers = computersList
                .Where(c => c.Manufacturer().ToLower().Contains(filterText)||c.ProcessorName().ToLower().Contains(filterText))
                .OrderByDescending(c => c.CalculateQuality());
            listBox1.Items.Clear();
            foreach (var computer in filteredComputers)
            {
                listBox1.Items.Add(computer.GetInfo());
            }
            buttonReset.Visible = true;
            UpdateLabelStatus();
        }
        private void buttonReset_Click(object sender, EventArgs e)
        {
            textBoxFilter.Text = "";
            UpdateComputerList();
            UpdateLabelStatus();
            buttonReset.Visible = false;
        }
        //Обновление списка компьютеров
        private void UpdateComputerList()
        {
            listBox1.Items.Clear();
            var sorted = computersList.OrderByDescending(c => c.CalculateQuality());

            foreach (var comp in sorted)
            {
                listBox1.Items.Add(comp.GetInfo());
            }
        }

        //Очистка всех полей
        private void ClearInputs()
        {
            textBoxProcessor.Clear();
            textBoxFrequency.Clear();
            textBoxRam.Clear();
            textBoxManufacturer.Clear();
            textBoxHdd.Clear();
            textBoxMemory.Clear();
            checkBox2.Checked = false;
            checkBox1.Checked = false;
        }

        //Метод для отображения статистики
        private void UpdateLabelStatus()
        {
            if (computersList.Count == 0)
            {
                labelStats.Text = "Нет данных о компьютерах";
            }
            int totalComputers = computersList.Count;
            int improvedCount = computersList.OfType<ImprovementComputer>().Count();
            int regularCount = totalComputers - improvedCount;
            labelStats.Text =
                $"Общее количество: {totalComputers}\n" +
                $"─────────────────────\n" +
                $"• Обычных: {regularCount}\n" +
                $"• Улучшенных: {improvedCount}";
        }
        // Добавление компьютера в коллекцию - по объекту
        public void AddComputer(Computer computer)
        {
            if (computer == null)
            {
                MessageBox.Show("Компьютер не может быть null");
            }
            computersList.Add(computer);
            UpdateComputerList();
            UpdateLabelStatus();
            MessageBox.Show($"Компьютер {computer.ProcessorName()} добавлен в коллекцию");
        }

        // Добавление компьютера в коллекцию перегрузка - по параметрам
        public void AddComputer(string processorName, double frequency, int ramSize, string manufacturer, DateTime dateProduction)
        {
            Computer computer = new Computer(processorName, frequency, ramSize, manufacturer, dateProduction);
            computersList.Add(computer);
            UpdateComputerList();
            UpdateLabelStatus();
            MessageBox.Show($"Компьютер {processorName} создан и добавлен в коллекцию");
        }
        // Удаление компьютера из коллекции - по объекту
        public bool RemoveComputer(Computer computer)
        {
            if (computer == null)
            {
                MessageBox.Show("Компьютер не может быть null");
            }
            bool removed = computersList.Remove(computer);
            if (removed)
            {
                UpdateComputerList();
                UpdateLabelStatus();
                MessageBox.Show($"Компьютер {computer.ProcessorName()} удален из коллекции");
            }
            else
            {
                MessageBox.Show($"Компьютер {computer.ProcessorName()} не найден в коллекции");
            }
            return removed;
        }
        // Удаление компьютера из коллекции (перегрузка 2) - по индексу
        public bool RemoveComputer(int index)
        {
            if (index < 0 || index >= computersList.Count)
            {
                MessageBox.Show($"Индекс {index} выходит за пределы коллекции");
            }
            Computer computer = computersList[index];
            computersList.RemoveAt(index);
            UpdateComputerList();
            UpdateLabelStatus();
            MessageBox.Show($"Компьютер {computer.ProcessorName()} удален по индексу {index}");
            return true;
        }
        private void buttonAddCollection_Click_1(object sender, EventArgs e)
        {
            Computer Computer = new Computer("Processor", 2.5, 4, "Manufacturer", DateTime.Now);
            AddComputer(Computer);
        }

        private void buttonAddByParams_Click_1(object sender, EventArgs e)
        {
            AddComputer("Processor", 3.0, 8, "Manufacturer", DateTime.Now);
        }

        private void buttonRemoveByObject_Click_1(object sender, EventArgs e)
        {
            if (computersList.Count > 0)
            {
                RemoveComputer(computersList[computersList.Count - 1]);
            }
            else
            {
                MessageBox.Show("Удалять нечего");
            }
        }

        private void buttonRemoveByIndex_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                int selectedIndex = listBox1.SelectedIndex;
                var filter = computersList.OrderByDescending(c => c.CalculateQuality()).ToList();

                if (selectedIndex < filter.Count)
                {
                    Computer computerRemove = filter[selectedIndex];
                    RemoveComputer(computerRemove);
                }
            }
            else
            {
                MessageBox.Show("Выберите компьютер для удаления");
            }
        }
    }
}