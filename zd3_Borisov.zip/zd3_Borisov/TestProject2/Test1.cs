﻿using zd3_Borisov;
namespace TestProject2
{
    [TestClass]
    public class ComputerTests
    {
        [TestMethod]
        public void CalculateQuality_TestComputer_()
        {
            var computer = new Computer("Intel i5", 3.2, 8, "Dell", DateTime.Now);
            double quality = computer.CalculateQuality();
            double expectedQuality = 0.3 * 3.2 + 8; //0.96 + 8 = 8.96
            Assert.AreEqual(expectedQuality, quality);
        }
        [TestMethod]
        public void CalculateQuality_TestImprovementComputer()
        {
            var computer = new ImprovementComputer("AMD Ryzen", 3.8, 16, "HP",DateTime.Now, 1000, true, 32);
            double quality = computer.CalculateQuality();
            double baseQuality = 0.3 * 3.8 + 16;//17.14
            double expected = baseQuality + 0.5 * 1000;//517.14
            Assert.AreEqual(expected, quality);
        }
        [TestMethod]
        public void addComputerTest()
        {
            List<Computer> computers = new List<Computer>();
            Computer computer = new Computer("intel", 3.5, 16, "Intel", DateTime.Now);
            int countNow = computers.Count;
            Computer.AddComputer(computers, computer);
            Assert.AreEqual(countNow + 1, computers.Count);
        }
    }
}
